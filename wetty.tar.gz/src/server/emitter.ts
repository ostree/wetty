import WeTTy from './wetty';

export default new WeTTy();
